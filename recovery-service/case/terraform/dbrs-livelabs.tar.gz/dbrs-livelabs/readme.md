# Livelabs terraform config

This terraform config provisions a DBaaS DB that sends backup to DBRS.

## Required Variables

| Variable Name | Description |
|--- |--- |
| ociTenancyOcid | Tenancy OCID |
| ociCompartmentOcid | Compartment OCID |
| ociVcnOcid | target VCN for resouces (Need to meet certain requirements. See Below.) |
| ociPublicSubnetOcid | target subnet for resources
| ociUserPassword | DB admin password |
| resUserPublicKey | SSH public keys for DB |

## VCN requirements

The target VCN must have the following Security List and Route Table rules:

- Security List Ingress rules
    - Port 8005 is open to allow HTTP traffic
    - Port 2484 is open to allow SQL Net traffic
- Route Table rules
    - Provision a Service Gatweay for "ALL OCI Services".
    - Route traffic via Service Gateway, destination "0.0.0.0/0".
        - To allow DB connection to objectstore and dcs agent.

Terraform files to provision a minimal VCN sufficient for DBRS backup found in `network` folder.